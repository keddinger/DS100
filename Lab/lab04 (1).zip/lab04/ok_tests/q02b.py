
test = {
  'name': 'q02b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> needs_log_transformation == "inc"
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
