
test = {
  'name': 'q04b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> alpha < 0.9 and alpha > 0.08
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
