test = {
  'name': 'Placeholder Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # This test is just here for the assignment to release properly
          >>> 1 + 1
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': r'''
      ''',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
