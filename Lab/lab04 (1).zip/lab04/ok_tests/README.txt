Test should be automatically generated.
