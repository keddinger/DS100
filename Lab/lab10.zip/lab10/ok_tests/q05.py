
test = {
  'name': 'q05',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> np.isclose(theta_hat_with_intercept, np.array([-2.1661333225821946,  1.035494603213118 ,  4.0238157334512685]), rtol=1e-2, atol=1e-2).all()
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
