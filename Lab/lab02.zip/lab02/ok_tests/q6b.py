test = {
  'name': 'Question 6b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> set(popular_songs.index) == {'Thinking Out Loud', 'One Dance', 'Sorry', 'Closer', 'Decpasito', 'Lean On'}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
