
test = {
  'name': 'q05',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> best_feature_set == ['RM', 'LSTAT', 'PTRATIO']
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
