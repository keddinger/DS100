
test = {
  'name': 'q03c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> np.allclose(conf_int_t, np.array([ -4.33307068,  14.61878496]))
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
