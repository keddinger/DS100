
test = {
  'name': 'q04g',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
'code': r"""
>>> conf_interval_endpoints[0] < conf_int_stu_endpoints[0]
True
>>> conf_interval_endpoints[1] < conf_int_stu_endpoints[1]
True

""",
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
